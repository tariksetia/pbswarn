/*
Module for datacast.go, implements tagged logging to file.

Copyright 2019 America's Public Television Stations
*/

package logging

import (
	"fmt"
	"log"
	"os"

	config "github.com/Tkanos/gonfig"
	// mariadb driver import
	_ "github.com/go-sql-driver/mysql"
)

// Configuration data structure for application config
// Configuration data structure for application config
type Configuration struct {
	Station   string
	Multicast string
	LogFile   string
}

// LogItem data structure for log entry
type LogItem struct {
	Time    string
	Source  string
	Message string
}

var cfg Configuration
var err error
var f *os.File
var f1 *os.File

func init() {

	// load station configuration
	cfg = Configuration{}
	if err := config.GetConf("./warnRx.conf", &cfg); err != nil {
		fmt.Println("Logging getting config:", err)
	}

}

// Log writes a log record
func Log(source string, message string) {

	//create a line buffer full of spaces
	line := make([]byte, 108)
	for i := range line {
		line[i] = 32
	}

	if len(message) > 80 {
		message = message[0:79]
	}

	copy(line[0:], message)
	copy(line[80:], source)

	// make sure the log file exists
	if _, err := os.Stat(cfg.LogFile); os.IsNotExist(err) {
		if f1, err = os.Create(cfg.LogFile); err != nil {
			log.Fatal("Cannot create file ", err)
		}
		f1.Close()
	}

	if f, err = os.OpenFile(cfg.LogFile, os.O_APPEND|os.O_WRONLY, 0644); err != nil {
		log.Fatal("Logger can't open logfile")
	}
	log.SetOutput(f)

	log.Println(string(line))

	f.Close()

}
