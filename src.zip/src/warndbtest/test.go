package main

import (
	"../cap"
	"../warndb"
)

func main() {
	alert := cap.ParseCAP([]byte(cap.TestMsg))
	//fmt.Println(cap.FormatCAP(alert))
	warndb.ToDB(alert, cap.TestMsg)
}
