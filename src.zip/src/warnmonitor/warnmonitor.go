/**************************************************************
 *
 *  Copyright (c) 2019 Public Broadcasting Service
 *  Contact: <warn@pbs.org>
 *  All Rights Reserved.
 *
 *  Version 2.5 4/1/2020
 *
 *************************************************************/

package main

import (
	"bytes"
	"database/sql"
	"fmt"
	"hash"
	"io/ioutil"
	"net"
	"net/http"
	"strings"

	"golang.org/x/net/ipv4"
	//"cap"
)

const postURL2 = "http://10.8.0.1:9110/addAlert"
const postURL = "https://egct53wru7.execute-api.us-east-1.amazonaws.com/prod"

var (
	inMessage bool
	message   []byte
	breaker   []byte
	lastHash  string
	replacer  strings.Replacer
	h         hash.Hash
	db        *sql.DB
	err       error
	result    sql.Result
	rows      *sql.Rows
	dispPoly  string
	channel   chan []byte
)

type mapItem struct {
	ID           string
	Sent         string
	Status       string
	MsgType      string
	Cmam         string
	Headline     string
	Source       string
	Levels       string
	ResponseType string
	Description  string
	Instruction  string
	Expires      string
	AreaDesc     string
	Geocodes     []string
	Polygons     string
}

// Run is a goroutine to monitor UDP packets from the WARN receiver and
// re-assemble
func main() {
	inMessage = false
	breaker = []byte{0x47, 0x09, 0x11} // Start of MPEG Packet break?
	if err != nil {
		fmt.Println("Create breaker", err)
	}
	breaker = []byte{0x47, 0x09, 0x11} // Start of MPEG Packet break?
	// set up the UDP monitor
	eth0, err := net.InterfaceByName("eth0")
	if err != nil {
		fmt.Println("InterfaceByName", err)
	}
	group := net.IPv4(224, 3, 0, 1)
	c, err := net.ListenPacket("udp4", "0.0.0.0:5000")
	if err != nil {
		fmt.Println("ListenPacket", err)
	}
	defer c.Close()
	p := ipv4.NewPacketConn(c)
	if err := p.JoinGroup(eth0, &net.UDPAddr{IP: group}); err != nil {
		fmt.Println("JoinGroup", err)
	}
	b := make([]byte, 1500)
	fmt.Println("Starting multicast monitoring from WARN receiver on 224.3.0.1")
	for {
		n, _, _, _ := p.ReadFrom(b)
		packetHandler(b, n)
	}
}

// process each multicast packet, pass along those for assembly
func packetHandler(b []byte, n int) {
	//fmt.Println("packet")
	msg := b[24:n]
	msg = removeAll(msg, breaker)               // take out MPEG packet breaks
	if bytes.Index(msg, []byte("CMAC")) == -1 { // process if not CMAC message
		assemble(msg)
	} else {
		go postXML("heartbeat")
	}
}

func assemble(msg []byte) {
	// if packet contains "<?xml ", start a new message
	st := bytes.Index(msg, []byte("<?xml "))
	if st != -1 {
		if !inMessage {
			inMessage = true
			msg = msg[st:] // trim off leading garbage
		}
		message = make([]byte, 0) // init a new message
	}
	// if packet contains "</ale" it's the end of the message
	en := bytes.Index(msg, []byte("</ale"))
	if inMessage && en != -1 {
		msg = msg[:en]                           // trim off trailing garbage
		msg = append(msg, []byte("</alert>")...) // repair the closing tag
		message = append(message, msg...)
		inMessage = false
		//fmt.Println(string(message))
		go postXML(string(message))
		return
	}
	// otherwise, if we're in message, append it
	if inMessage {
		message = append(message, msg...)
	}
}

// remove all instances of a byte slice from within another byte slice
func removeAll(source []byte, remove []byte) []byte {
	for bytes.Index(source, remove) > -1 {
		pnt := bytes.Index(source, remove)
		source = append(source[:pnt], source[pnt+12:]...)
	}
	return source
}

func postXML(message string) {
	
	/* // TEMPORARY
	if (message != "heartbeat") {
		fmt. Println("IN: ", message)
		alert := cap.ParseCAP([]byte(message))
		for index, info := range alert.Infos {
			if (info.Language == "es-us" || info.Language == "es-US") { 
				alert.Infos = append(alert.Infos[:index-1], alert.Infos[index+1:]...)
			}
		}
		message = cap.FormatCAP(alert)
		fmt.Println("OUT: ", message)
	}
	*/
	
	// send alert to old PBS server
	req, _ := http.NewRequest("POST", postURL, bytes.NewBuffer([]byte(message)))
	req.Header.Set("Content-Type", "application/xml")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("(warnmonitor.postXML send old)", err)
	}
	defer resp.Body.Close()

	// log response from PBS (old) server
	body, _ := ioutil.ReadAll(resp.Body)
	fmt.Println("(warnmonitor.postXML old)", resp.StatusCode, "-", string(body) ) //n["body"])

	// send alert to new PBS server
	req2, _ := http.NewRequest("POST", postURL2, bytes.NewBuffer([]byte(message)))
	req2.Header.Set("Content-Type", "application/xml")
	client2 := &http.Client{}
	resp2, err := client2.Do(req2)
	if err != nil {
		fmt.Println("(warnmonitor.postXML send new)", err)
	}
	defer resp2.Body.Close()

	// log response from PBS (new) server
	body2, _ := ioutil.ReadAll(resp2.Body)
	fmt.Println("(warnmonitor.postXML new)",resp2.StatusCode, "-", string(body2))


	return
}
