# Changelog

### 0.4
- browser support

### 0.3
- passing more information into {Function} config
- API change: returning {Object} with code, ast, comments and tokens attached instead of just a code {String}
- comments support

### 0.2 
- upgrade to Esprima 1.0.0

### 0.1
- first working version
