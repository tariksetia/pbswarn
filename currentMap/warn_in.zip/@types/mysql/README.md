# Installation
> `npm install --save @types/mysql`

# Summary
This package contains type definitions for mysql ( https://github.com/mysqljs/mysql ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mysql

Additional Details
 * Last updated: Tue, 23 Apr 2019 20:13:46 GMT
 * Dependencies: @types/node
 * Global values: none

# Credits
These definitions were written by  William Johnston <https://github.com/wjohnsto>, Kacper Polak <https://github.com/kacepe>, Krittanan Pingclasai <https://github.com/kpping>, James Munro <https://github.com/jdmunro>.
