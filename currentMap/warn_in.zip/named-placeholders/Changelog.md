1.1.0 - 21/09/2015
  - exception is now thrown if parameters are missing

1.0.0 - 14/09/2015
  - added double-semicolon placeholders ( see https://github.com/sidorares/node-mysql2/issues/176 )
  - added toNumbered helper ( postgres style $1 parameters )
